export const api_url = "https://poo-auth.vercel.app/";
export const headers =  { 'Content-Type': 'application/json' };