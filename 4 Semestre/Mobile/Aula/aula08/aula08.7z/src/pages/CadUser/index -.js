import AsyncStorage from '@react-native-async-storage/async-storage';
import { Form } from '@unform/mobile';
import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  StatusBar,
  StyleSheet,
  Text, TextInput, View
} from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { api_url, headers } from '../../variables';
import { Aviso, BoxForm, Container } from './styles';

export default function CadUser({ navigation }) {
    const formRef = useRef(null);
    const [Sev, setSev] = useState("error");
    const [Retorno, setRetorno] = useState("");
    const [FormValues, setFormValues] = useState([]);
    const [loading, setLoading] = useState(false); 

    function handleInputChange(input) {
        setFormValues((prevValues) => ({
            ...prevValues,
            [input.name]: input.value,
        }));
    }
    
    
}