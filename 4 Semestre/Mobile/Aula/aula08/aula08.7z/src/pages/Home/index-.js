import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {useEffect, useState} from 'react'
import {
  StatusBar,
  StyleSheet,
  Text, View
} from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { Container } from './styles';

export default function Login({}) {
  const [DadosUser, setDadosUser] = useState([]);
  return (
    <Container>
      <StatusBar color="white" backgroundColor={"#5e849d"}/>
      <View style={styles.ViewInicial}>
        <Text style={ styles.TextBody }>
            {`Olá! Seja bem vindo!`}
        </Text>
      </View>
  </Container>
  );
}

const styles = StyleSheet.create({
  ViewInicial: {
    marginBottom: 10,
    marginTop: 10
  },
  TextBody: {
    color: "#fff",
    fontSize: 23,
    marginBottom: 5,
    textAlign: "center"
  }
});