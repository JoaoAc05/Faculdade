import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useEffect, useState } from 'react';
import {
  StatusBar,
  StyleSheet,
  Text, View
} from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { Container } from './styles';

export default function Home({ navigation  }) {
  const [DadosUser, setDadosUser] = useState([]);

  useEffect(() => {
    (async () => {
      let Token = await AsyncStorage.getItem('@token_').then((data) => {
        return data;
      });

      if(!Token) {
        Sair()
      }else{
        await AsyncStorage.getItem('@dados_').then((data) => {
          setDadosUser(JSON.parse(data));
        });
      }
    })();
  }, [DadosUser]);

  return (
    <Container>
      <StatusBar color="white" backgroundColor={"#5e849d"}/>
      <View style={styles.ViewInicial}>
        {DadosUser.nome ? (
          <Text style={ styles.TextBody }>
              {`Olá! Seja bem vindo ${DadosUser.nome}`}
          </Text>
        ) : null }

        <TouchableOpacity onPress={(e) => Sair() }>
          <View style={styles.BotaoLink}>
            <Text style={styles.BotaoPadraoTexto}>Deslogar</Text> 
          </View>
        </TouchableOpacity>

      </View>
  </Container>
  );

  async function Sair(){
    let keys = ['@token_', '@dados_'];
    await AsyncStorage.multiRemove(keys, (err) => {
        navigation.navigate('Login');
    })
  }
}

const styles = StyleSheet.create({
  ViewInicial: {
    marginBottom: 10,
    marginTop: 10
  },
  TextBody: {
    color: "#fff",
    fontSize: 23,
    marginBottom: 5,
    textAlign: "center"
  },
  BotaoPadraoTexto: {
    color: "#fff",
    fontSize: 14
  },
  BotaoLink: {
    alignItems: 'center',
    padding: 15,
    margin: 5,
  },
});